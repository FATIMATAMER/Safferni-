from django.contrib import admin
from .models import BookingUser

# Register your models here.

admin.site.register(BookingUser)
